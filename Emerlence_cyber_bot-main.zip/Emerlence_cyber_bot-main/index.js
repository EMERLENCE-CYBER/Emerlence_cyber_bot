const helloCommand = require('./commands/helloCommand');
const helpCommand = require('./commands/helpCommand');
const goodbyeCommand = require('./commands/goodbyeCommand');
const otherCommand = require('./commands/otherCommands');

const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
require('dotenv').config();

// Create WhatsApp client
const client = new Client({
    authStrategy: new LocalAuth()
});

// Generate QR code in terminal
client.on('qr', qr => {
    qrcode.generate(qr, { small: true });
    console.log('Scan the QR code to log in');
});

// When client is ready
client.on('ready', () => {
    console.log('Bot is now ready!');
});

// When a message is received
client.on('message', message => {
    console.log('Received message:', message.body);

    const command = message.body.trim().toLowerCase();

    if (command === 'hello') {
        helloCommand.execute(message);
    } else if (command === 'help') {
        helpCommand.execute(message);
    } else if (command === 'goodbye') {
        goodbyeCommand.execute(message);
        } else if (command === 'other') {
        otherCommand.execute(message);
    } else {
        message.reply('Sorry, I did not understand that. Type "help" to see available commands.');
    }
});

// Start the client
client.initialize();
```

---