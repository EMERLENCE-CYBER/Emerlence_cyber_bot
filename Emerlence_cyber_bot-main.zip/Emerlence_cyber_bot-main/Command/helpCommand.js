module.exports = {
    execute: (message) => {
        message.reply(`Here are the commands you can use:
- *hello* – Greet the bot
- *help* – Show this help message
- *goodbye* – Say goodbye
- *other* – Some other response`);
    }
};
```

---

