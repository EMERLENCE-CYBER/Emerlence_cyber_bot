module.exports = {
    execute: (message) => {
        message.reply('Goodbye! 👋 Have a great day!');
    }
};
```

---
