module.exports = {
    execute: (message) => {
        message.reply('Hello there! 👋 I am your WhatsApp bot.');
    }
};
```

---

